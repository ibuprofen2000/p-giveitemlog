Config = {}

-- ============================================================
--  INVENTORY SYSTEM
--  Supported: 'ox_inventory', 'qb-inventory', 'qs-inventory',
--             'codem-inventory', 'tgiann-inventory'
-- ============================================================
Config.InventorySystem = 'ox_inventory'

-- ============================================================
--  DISCORD WEBHOOKS
--  Leave a URL empty ('') to disable that specific log.
-- ============================================================
Config.Webhooks = {
    GiveItem    = '',  -- Player gave an item to another player
    DropItem    = '',  -- Player dropped an item on the ground
    PickupItem  = '',  -- Player picked up an item from the ground
    TakeItem    = '',  -- Player took an item from another player's inventory
    MoveItem    = '',  -- Player moved / swapped items inside their own inventory
    StashStore  = '',  -- Player stored an item in a stash / trunk / glovebox
    StashTake   = '',  -- Player took an item from a stash / trunk / glovebox
}

-- ============================================================
--  EMBED SETTINGS
-- ============================================================
Config.BotName   = 'Polar Logs'
Config.BotAvatar = 'https://i.imgur.com/xxxxxxx.png'  -- Change to your avatar URL

Config.EmbedColors = {
    GiveItem    = 3066993,   -- Green
    DropItem    = 15158332,  -- Red
    PickupItem  = 3447003,   -- Blue
    TakeItem    = 10181046,  -- Purple
    MoveItem    = 16776960,  -- Yellow
    StashStore  = 16753920,  -- Orange
    StashTake   = 1752220,   -- Dark Green
}

Config.EmbedFooter = 'Polar Logs • Inventory Logger'

-- ============================================================
--  FRAMEWORK (auto-detected, but you can force it)
--  Supported: 'auto', 'esx', 'qb', 'standalone'
-- ============================================================
Config.Framework = 'auto'

-- ============================================================
--  MISC
-- ============================================================
Config.DateFormat   = '%Y-%m-%d %H:%M:%S'   -- Timestamp format
Config.LogToConsole = true                    -- Also print logs in server console
