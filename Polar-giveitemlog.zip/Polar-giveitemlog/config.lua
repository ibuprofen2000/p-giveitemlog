Config = {}

-- ============================================================
--  INVENTORY SYSTEM
--  Supported: 'ox_inventory', 'qb-inventory', 'qs-inventory',
--             'codem-inventory', 'tgiann-inventory'
-- ============================================================
Config.InventorySystem = 'ox_inventory'

----------------------------------------------------
Config.BotName   = 'Polar Logs'
Config.BotAvatar = 'https://i.imgur.com/xxxxxxx.png'  -- Change to your avatar URL

Config.EmbedColors = {
    GiveItem    = 3066993,   -- Green
    DropItem    = 15158332,  -- Red
    PickupItem  = 3447003,   -- Blue
    TakeItem    = 10181046,  -- Purple
    MoveItem    = 16776960,  -- Yellow
    StashStore  = 16753920,  -- Orange
    StashTake   = 1752220,   -- Dark Green
}

Config.EmbedFooter = 'Polar Logs • Inventory Logger'

-- Esx , Qb-core , Standalone (auto-detect)
Config.Framework = 'auto'

-- ============================================================
--  MISC
-- ============================================================
Config.DateFormat   = '%Y-%m-%d %H:%M:%S'   -- Timestamp format
Config.LogToConsole = false                   -- Also print logs in server console
