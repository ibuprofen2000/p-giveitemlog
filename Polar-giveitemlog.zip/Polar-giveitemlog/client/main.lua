-- ============================================================
--  POLAR INVENTORY LOGGER — CLIENT
--  Handles client-side pickup / drop notifications for
--  inventory systems that fire client events.
-- ============================================================

-- ox_inventory client-side item notifications (optional)
if Config.InventorySystem == 'ox_inventory' then

    RegisterNetEvent('ox_inventory:itemReceived', function(itemName, count)
        -- Silently handled; server hooks do the logging
    end)

end

-- QB-Inventory client-side drop detection
if Config.InventorySystem == 'qb-inventory' then

    RegisterNetEvent('qb-inventory:client:DropItem', function(itemName, amount)
        TriggerServerEvent('polar-logs:client:dropItem', itemName, amount)
    end)

    RegisterNetEvent('qb-inventory:client:PickupItem', function(itemName, amount)
        TriggerServerEvent('polar-logs:client:pickupItem', itemName, amount)
    end)

end

-- QS-Inventory client-side detection
if Config.InventorySystem == 'qs-inventory' then

    RegisterNetEvent('qs-inventory:client:DropItem', function(itemName, amount)
        TriggerServerEvent('polar-logs:client:dropItem', itemName, amount)
    end)

end
