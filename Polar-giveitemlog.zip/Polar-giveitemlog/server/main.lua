-- ============================================================
--  POLAR INVENTORY LOGGER — SERVER
-- ============================================================

local Framework = nil
local ESX, QBCore = nil, nil

-- ============================================================
--  SECURITY — Webhook URL Validation
-- ============================================================
local validatedWebhooks = {}

local function IsValidDiscordWebhook(url)
    if not url or url == '' then return false end
    -- Only allow official Discord webhook URLs
    return string.match(url, '^https://discord%.com/api/webhooks/%d+/[%w_-]+$') ~= nil
        or string.match(url, '^https://discordapp%.com/api/webhooks/%d+/[%w_-]+$') ~= nil
end

local function ValidateWebhooks()
    if not Webhooks then
        print('^1[Polar-Logs]^0 server/webhooks.lua not loaded! No webhooks configured.')
        return
    end
    for key, url in pairs(Webhooks) do
        if url and url ~= '' then
            if IsValidDiscordWebhook(url) then
                validatedWebhooks[key] = url
                print(('^2[Polar-Logs]^0 Webhook [%s] validated'):format(key))
            else
                print(('^1[Polar-Logs]^0 Webhook [%s] REJECTED — invalid Discord URL'):format(key))
            end
        end
    end
end

-- ============================================================
--  SECURITY — Rate Limiting
-- ============================================================
local rateLimits = {}  -- [src] = { count = n, resetAt = tick }
local RATE_WINDOW   = 10000  -- 10 seconds
local RATE_MAX      = 15     -- max actions per window per player

local function IsRateLimited(src)
    if not src or src <= 0 then return false end
    local now = GetGameTimer()
    local entry = rateLimits[src]

    if not entry or now >= entry.resetAt then
        rateLimits[src] = { count = 1, resetAt = now + RATE_WINDOW }
        return false
    end

    entry.count = entry.count + 1
    if entry.count > RATE_MAX then
        print(('^1[Polar-Logs]^0 Rate-limited player %s (%s) — possible exploit'):format(
            tostring(src), GetPlayerName(src) or 'Unknown'
        ))
        return true
    end

    return false
end

-- Clean up rate limit entries for disconnected players
AddEventHandler('playerDropped', function()
    rateLimits[source] = nil
end)

-- ============================================================
--  FRAMEWORK DETECTION
-- ============================================================
CreateThread(function()
    local fw = Config.Framework

    if fw == 'auto' or fw == 'esx' then
        if GetResourceState('es_extended') == 'started' then
            ESX = exports['es_extended']:getSharedObject()
            Framework = 'esx'
            print('^2[Polar-Logs]^0 Framework detected: ESX')
            return
        end
    end

    if fw == 'auto' or fw == 'qb' then
        if GetResourceState('qb-core') == 'started' then
            QBCore = exports['qb-core']:GetCoreObject()
            Framework = 'qb'
            print('^2[Polar-Logs]^0 Framework detected: QBCore')
            return
        end
    end

    Framework = 'standalone'
    print('^3[Polar-Logs]^0 Running in standalone mode')
end)

-- ============================================================
--  HELPERS
-- ============================================================
local function GetPlayerCharName(src)
    if not src or src <= 0 then return 'Unknown' end

    if Framework == 'esx' and ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then return xPlayer.getName() end
    elseif Framework == 'qb' and QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local info = Player.PlayerData.charinfo
            return ('%s %s'):format(info.firstname, info.lastname)
        end
    end

    local nativeName = GetPlayerName(src)
    if nativeName and nativeName ~= '' then
        return nativeName
    end

    return ('Player %d'):format(src)
end

local function GetIdentifier(src)
    if not src or src <= 0 then return 'N/A' end

    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if string.find(id, 'license:') then
            return id
        end
    end

    return 'N/A'
end

local function GetSteamHex(src)
    if not src or src <= 0 then return 'N/A' end

    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if string.find(id, 'steam:') then
            return id
        end
    end

    return 'N/A'
end

local function GetDiscordId(src)
    if not src or src <= 0 then return 'N/A' end

    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if string.find(id, 'discord:') then
            return id
        end
    end

    return 'N/A'
end

-- ============================================================
--  DISCORD WEBHOOK SENDER
-- ============================================================
local function SendToDiscord(webhookType, title, description, color)
    local webhook = validatedWebhooks[webhookType]
    if not webhook then return end

    local embed = {
        {
            ['title']       = title,
            ['description'] = description,
            ['color']       = color or Config.EmbedColors[webhookType] or 16777215,
            ['footer']      = {
                ['text'] = Config.EmbedFooter,
            },
            ['timestamp']   = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        }
    }

    PerformHttpRequest(webhook, function(err, text, headers) end, 'POST', json.encode({
        username  = Config.BotName,
        avatar_url = Config.BotAvatar,
        embeds    = embed,
    }), { ['Content-Type'] = 'application/json' })
end

-- ============================================================
--  LOG BUILDER
-- ============================================================
local function BuildPlayerInfo(src)
    if not src or src <= 0 then
        return '**Player:** N/A'
    end
    local name  = GetPlayerCharName(src)
    local id    = src
    local steam = GetSteamHex(src)
    local disc  = GetDiscordId(src)
    local lic   = GetIdentifier(src)

    return ('**Player:** %s (ID: %s)\n**Steam:** `%s`\n**Discord:** `%s`\n**License:** `%s`'):format(
        name, id, steam, disc, lic
    )
end

local function LogAction(webhookType, title, source, target, itemName, itemCount, extra)
    local timestamp = os.date(Config.DateFormat)
    local lines = {}

    lines[#lines+1] = '>>> **Action:** ' .. title
    lines[#lines+1] = '**Time:** ' .. timestamp
    lines[#lines+1] = ''
    lines[#lines+1] = '__Source__'
    lines[#lines+1] = BuildPlayerInfo(source)
    lines[#lines+1] = ''

    if target and target > 0 then
        lines[#lines+1] = '__Target__'
        lines[#lines+1] = BuildPlayerInfo(target)
        lines[#lines+1] = ''
    end

    lines[#lines+1] = ('**Item:** `%s` x%s'):format(tostring(itemName), tostring(itemCount or 1))

    if extra then
        lines[#lines+1] = ('**Details:** %s'):format(tostring(extra))
    end

    local description = table.concat(lines, '\n')

    if Config.LogToConsole then
        print(('[Polar-Logs] [%s] %s | Player %s | Item: %s x%s'):format(
            webhookType, title, tostring(source), tostring(itemName), tostring(itemCount or 1)
        ))
    end

    SendToDiscord(webhookType, title, description)
end

-- ============================================================
--  OX_INVENTORY HOOKS
-- ============================================================
local function SetupOxInventory()
    if GetResourceState('ox_inventory') ~= 'started' then
        print('^1[Polar-Logs]^0 ox_inventory is not started!')
        return
    end

    -- Listen now via the export-based event hooks ox_inventory provides
    exports('ox_inventory'):registerHook('swapItems', function(payload)
        if not payload then return true end

        local src       = payload.source
        local fromInv   = payload.fromInventory
        local toInv     = payload.toInventory
        local itemName  = payload.fromSlot and payload.fromSlot.name or 'unknown'
        local itemCount = payload.count or (payload.fromSlot and payload.fromSlot.count) or 1

        -- Determine action type
        local fromType = type(fromInv) == 'string' and fromInv or tostring(fromInv)
        local toType   = type(toInv)   == 'string' and toInv   or tostring(toInv)

        local fromIsPlayer = type(fromInv) == 'number'
        local toIsPlayer   = type(toInv)   == 'number'

        -- Player to player — give item
        if fromIsPlayer and toIsPlayer and fromInv ~= toInv then
            LogAction('GiveItem', 'Item Given', fromInv, toInv, itemName, itemCount)
        -- Player to stash
        elseif fromIsPlayer and not toIsPlayer then
            LogAction('StashStore', 'Item Stored', src, nil, itemName, itemCount, ('Stash: `%s`'):format(toType))
        -- Stash to player
        elseif not fromIsPlayer and toIsPlayer then
            LogAction('StashTake', 'Item Taken from Stash', src, nil, itemName, itemCount, ('Stash: `%s`'):format(fromType))
        -- Same inventory move
        elseif fromInv == toInv then
            LogAction('MoveItem', 'Item Moved', src, nil, itemName, itemCount)
        end

        return true
    end, {})

    -- Drop item on ground
    exports('ox_inventory'):registerHook('createDrop', function(payload)
        if not payload then return true end

        local src = payload.source
        if not src or src <= 0 then return true end

        local items = payload.items
        if items then
            for _, item in pairs(items) do
                local itemName  = item.name or 'unknown'
                local itemCount = item.count or 1
                LogAction('DropItem', 'Item Dropped', src, nil, itemName, itemCount)
            end
        end

        return true
    end, {})

    print('^2[Polar-Logs]^0 ox_inventory hooks registered successfully')
end

-- ============================================================
--  QB-INVENTORY HOOKS
-- ============================================================
local function SetupQBInventory()
    if GetResourceState('qb-inventory') ~= 'started' then
        print('^1[Polar-Logs]^0 qb-inventory is not started!')
        return
    end

    -- qb-inventory fires server events for item actions
    RegisterNetEvent('qb-inventory:server:GiveItem', function(target, itemName, amount)
        local src = source
        LogAction('GiveItem', 'Item Given', src, target, itemName, amount)
    end)

    RegisterNetEvent('qb-inventory:server:Drop', function(itemName, amount)
        local src = source
        LogAction('DropItem', 'Item Dropped', src, nil, itemName, amount)
    end)

    RegisterNetEvent('qb-inventory:server:Pickup', function(itemName, amount)
        local src = source
        LogAction('PickupItem', 'Item Picked Up', src, nil, itemName, amount)
    end)

    print('^2[Polar-Logs]^0 qb-inventory hooks registered successfully')
end

-- ============================================================
--  QS-INVENTORY HOOKS
-- ============================================================
local function SetupQSInventory()
    if GetResourceState('qs-inventory') ~= 'started' then
        print('^1[Polar-Logs]^0 qs-inventory is not started!')
        return
    end

    RegisterNetEvent('qs-inventory:server:GiveItem', function(target, itemName, amount)
        local src = source
        LogAction('GiveItem', 'Item Given', src, target, itemName, amount)
    end)

    RegisterNetEvent('qs-inventory:server:DropItem', function(itemName, amount)
        local src = source
        LogAction('DropItem', 'Item Dropped', src, nil, itemName, amount)
    end)

    RegisterNetEvent('qs-inventory:server:PickupItem', function(itemName, amount)
        local src = source
        LogAction('PickupItem', 'Item Picked Up', src, nil, itemName, amount)
    end)

    print('^2[Polar-Logs]^0 qs-inventory hooks registered successfully')
end

-- ============================================================
--  CODEM-INVENTORY HOOKS
-- ============================================================
local function SetupCodemInventory()
    if GetResourceState('codem-inventory') ~= 'started' then
        print('^1[Polar-Logs]^0 codem-inventory is not started!')
        return
    end

    RegisterNetEvent('codem-inventory:server:GiveItem', function(target, itemName, amount)
        local src = source
        LogAction('GiveItem', 'Item Given', src, target, itemName, amount)
    end)

    RegisterNetEvent('codem-inventory:server:DropItem', function(itemName, amount)
        local src = source
        LogAction('DropItem', 'Item Dropped', src, nil, itemName, amount)
    end)

    print('^2[Polar-Logs]^0 codem-inventory hooks registered successfully')
end

-- ============================================================
--  TGIANN-INVENTORY HOOKS
-- ============================================================
local function SetupTgiannInventory()
    if GetResourceState('tgiann-inventory') ~= 'started' then
        print('^1[Polar-Logs]^0 tgiann-inventory is not started!')
        return
    end

    RegisterNetEvent('tgiann-inventory:server:GiveItem', function(target, itemName, amount)
        local src = source
        LogAction('GiveItem', 'Item Given', src, target, itemName, amount)
    end)

    RegisterNetEvent('tgiann-inventory:server:DropItem', function(itemName, amount)
        local src = source
        LogAction('DropItem', 'Item Dropped', src, nil, itemName, amount)
    end)

    print('^2[Polar-Logs]^0 tgiann-inventory hooks registered successfully')
end

-- ============================================================
--  INITIALIZATION
-- ============================================================
CreateThread(function()
    Wait(2000) -- Wait for resources to be fully started

    -- Validate webhook URLs before anything else
    ValidateWebhooks()

    local inv = Config.InventorySystem

    if inv == 'ox_inventory' then
        SetupOxInventory()
    elseif inv == 'qb-inventory' then
        SetupQBInventory()
    elseif inv == 'qs-inventory' then
        SetupQSInventory()
    elseif inv == 'codem-inventory' then
        SetupCodemInventory()
    elseif inv == 'tgiann-inventory' then
        SetupTgiannInventory()
    else
        print('^1[Polar-Logs]^0 Unknown inventory system: ' .. tostring(inv))
    end
end)

-- ============================================================
--  CLIENT EVENT HANDLERS (for inventories that fire client events)
-- ============================================================
RegisterNetEvent('polar-logs:client:dropItem', function(itemName, amount)
    local src = source
    if not src or src <= 0 then return end
    if IsRateLimited(src) then return end
    -- Sanitize input from client
    if type(itemName) ~= 'string' or type(amount) ~= 'number' then return end
    if #itemName > 50 or amount < 0 or amount > 100000 then return end
    LogAction('DropItem', 'Item Dropped', src, nil, itemName, amount)
end)

RegisterNetEvent('polar-logs:client:pickupItem', function(itemName, amount)
    local src = source
    if not src or src <= 0 then return end
    if IsRateLimited(src) then return end
    -- Sanitize input from client
    if type(itemName) ~= 'string' or type(amount) ~= 'number' then return end
    if #itemName > 50 or amount < 0 or amount > 100000 then return end
    LogAction('PickupItem', 'Item Picked Up', src, nil, itemName, amount)
end)


