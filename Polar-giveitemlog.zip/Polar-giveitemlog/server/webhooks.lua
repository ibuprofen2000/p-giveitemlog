-- This Loads Server-side Dont worry about ur webhooks being taken.
Webhooks = {
    GiveItem    = '',  -- Player gave an item to another player
    DropItem    = '',  -- Player dropped an item on the ground
    PickupItem  = '',  -- Player picked up an item from the ground
    TakeItem    = '',  -- Player took an item from another player's inventory
    MoveItem    = '',  -- Player moved / swapped items inside their own inventory
    StashStore  = '',  -- Player stored an item in a stash / trunk / glovebox
    StashTake   = '',  -- Player took an item from a stash / trunk / glovebox
}
