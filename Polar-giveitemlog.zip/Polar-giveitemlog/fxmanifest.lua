fx_version 'cerulean'
game 'gta5'

author 'PolarX'
description 'Give Item Log + Discord Webhook'
version '1.0.0'

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/main.lua',
}

client_scripts {
    'client/main.lua',
}

lua54 'yes'

escrow_ignore {
    'config.lua',
}